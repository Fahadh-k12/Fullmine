"use client";

import { useState } from "react";
import { useSession } from "next-auth/react";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import * as z from "zod";
import { useRouter } from "next/navigation";
import { AlertCircle, Upload as UploadIcon } from "lucide-react";

import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { toast } from "@/hooks/use-toast";
import { UploadDropzone } from "@/lib/uploadthing";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { CONTENT_CATEGORIES, MUSIC_GENRES } from "@/lib/constants";

// Form schema
const formSchema = z.object({
  title: z.string().min(2, {
    message: "Title must be at least 2 characters.",
  }),
  caption: z.string().min(2, {
    message: "Caption must be at least 2 characters.",
  }),
  contentType: z.enum(["video", "photo", "music", "audio"]),
  contentUrl: z.string().min(1, {
    message: "Content URL is required.",
  }),
  thumbnailUrl: z.string().optional(),
  albumArt: z.string().optional(),
  genre: z.string().optional(),
});

type FormValues = z.infer<typeof formSchema>;

export default function UploadPage() {
  const router = useRouter();
  const { data: session } = useSession();
  const [isLoading, setIsLoading] = useState(false);
  const [contentType, setContentType] = useState<"video" | "photo" | "music" | "audio">("photo");

  // Check if user is premium for music uploads
  const isPremium = session?.user?.isPremium || false;

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      title: "",
      caption: "",
      contentType: "photo",
      contentUrl: "",
      thumbnailUrl: "",
      albumArt: "",
      genre: "",
    },
  });

  // Update content type when selection changes
  const onContentTypeChange = (value: string) => {
    setContentType(value as "video" | "photo" | "music" | "audio");
    form.setValue("contentType", value as "video" | "photo" | "music" | "audio");
  };

  async function onSubmit(values: FormValues) {
    try {
      setIsLoading(true);

      // Here would be the API call to save the content
      console.log("Submitting content:", values);

      toast({
        title: "Content uploaded successfully",
        description: "Your content is now available on your profile",
      });

      router.push("/profile");
    } catch (error) {
      console.error("Upload error:", error);
      toast({
        title: "Error uploading content",
        description: "Something went wrong",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  }

  // Render upload component based on content type
  const renderUploadComponent = () => {
    if (contentType === "music" && !isPremium) {
      return (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Premium required</AlertTitle>
          <AlertDescription>
            Music upload is only available for premium users.
            <Button variant="link" className="p-0 h-auto text-destructive-foreground underline" onClick={() => router.push("/premium")}>
              Upgrade to Premium
            </Button>
          </AlertDescription>
        </Alert>
      );
    }

    const uploadTypeMap = {
      photo: "image",
      video: "video",
      music: "audio",
      audio: "audio",
    };

    const fileType = uploadTypeMap[contentType];

    return (
      <UploadDropzone
        endpoint={fileType}
        onClientUploadComplete={(res) => {
          if (res && res.length > 0) {
            const file = res[0];
            form.setValue("contentUrl", file.url);

            // For music, we also need to set the album art
            if (contentType === "music" || contentType === "audio") {
              form.setValue("thumbnailUrl", "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?auto=format&fit=crop&w=800&q=60");
            }

            toast({
              title: "File uploaded",
              description: "Your file has been uploaded successfully",
            });
          }
        }}
        onUploadError={(error: Error) => {
          toast({
            title: "Error uploading file",
            description: error.message,
            variant: "destructive",
          });
        }}
      />
    );
  };

  return (
    <div className="container max-w-4xl mx-auto py-6">
      <Card>
        <CardHeader>
          <CardTitle className="text-2xl">Upload Content</CardTitle>
          <CardDescription>
            Share your creativity with the world
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
              <FormField
                control={form.control}
                name="contentType"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Content Type</FormLabel>
                    <Select
                      defaultValue={field.value}
                      onValueChange={(value) => {
                        field.onChange(value);
                        onContentTypeChange(value);
                      }}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select content type" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {CONTENT_CATEGORIES.map((category) => (
                          <SelectItem
                            key={category.value}
                            value={category.value}
                            disabled={category.value === "music" && !isPremium}
                          >
                            {category.title}
                            {category.value === "music" && !isPremium && " (Premium only)"}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormDescription>
                      Select the type of content you want to upload
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {contentType === "music" && (
                <FormField
                  control={form.control}
                  name="genre"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Genre</FormLabel>
                      <Select
                        defaultValue={field.value}
                        onValueChange={field.onChange}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select genre" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {MUSIC_GENRES.map((genre) => (
                            <SelectItem
                              key={genre.value}
                              value={genre.value}
                            >
                              {genre.title}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormDescription>
                        Select the genre of your music
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              )}

              <FormField
                control={form.control}
                name="title"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Title</FormLabel>
                    <FormControl>
                      <Input placeholder="Enter a title" {...field} />
                    </FormControl>
                    <FormDescription>
                      A title that describes your {contentType}
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="caption"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Caption</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="Write a caption for your content..."
                        className="min-h-32"
                        {...field}
                      />
                    </FormControl>
                    <FormDescription>
                      Add hashtags to make your content more discoverable
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Upload section */}
              <div className="space-y-4">
                <div className="flex items-center gap-2">
                  <UploadIcon className="h-5 w-5" />
                  <h3 className="text-lg font-medium">Upload {contentType}</h3>
                </div>
                {renderUploadComponent()}
                <FormField
                  control={form.control}
                  name="contentUrl"
                  render={({ field }) => (
                    <FormItem className="hidden">
                      <FormControl>
                        <Input {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <Button
                type="submit"
                className="w-full"
                disabled={isLoading || (contentType === "music" && !isPremium)}
              >
                {isLoading ? "Uploading..." : "Upload Content"}
              </Button>
            </form>
          </Form>
        </CardContent>
      </Card>
    </div>
  );
}
