"use client";

import { useSession } from "next-auth/react";
import { useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CalendarDays, MapPin, Link as LinkIcon, Settings, Grid, Music, Video, Image } from "lucide-react";
import Link from "next/link";
import { getInitials } from "@/lib/utils";
import { ScrollArea } from "@/components/ui/scroll-area";

// Mock data
const PROFILE_DATA = {
  bio: "Digital creator | Sharing my passion for music and photography | Exploring the world one post at a time ✨",
  location: "New York, NY",
  website: "https://example.com",
  joinedDate: "January 2023",
  stats: {
    posts: 42,
    followers: 3240,
    following: 892,
  },
};

interface PhotoItem {
  id: string;
  thumbnailUrl: string;
  title: string;
  likes: number;
}

interface VideoItem {
  id: string;
  thumbnailUrl: string;
  title: string;
  likes: number;
  duration: string;
}

interface MusicItem {
  id: string;
  albumArt: string;
  title: string;
  artist: string;
  likes: number;
  duration: string;
}

const USER_CONTENT = {
  photos: [
    {
      id: "p1",
      thumbnailUrl: "https://images.unsplash.com/photo-1546768292-fb12f6c92568?ixid=MnwxMjA3fDB8MHxzZWFyY2h8Mnx8Y2l0eXxlbnwwfHwwfHw%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=60",
      title: "Urban sunset",
      likes: 245,
    },
    {
      id: "p2",
      thumbnailUrl: "https://images.unsplash.com/photo-1473496169904-658ba7c44d8a?ixid=MnwxMjA3fDB8MHxzZWFyY2h8NHx8c2t5c2NyYXBlcnxlbnwwfHwwfHw%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=60",
      title: "Skyscrapers",
      likes: 187,
    },
    {
      id: "p3",
      thumbnailUrl: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?ixid=MnwxMjA3fDB8MHxzZWFyY2h8MTB8fG1vdW50YWlufGVufDB8fDB8fA%3D%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=60",
      title: "Mountain view",
      likes: 324,
    },
    {
      id: "p4",
      thumbnailUrl: "https://images.unsplash.com/photo-1519125323398-675f0ddb6308?ixid=MnwxMjA3fDB8MHxzZWFyY2h8M3x8YmVhY2h8ZW58MHx8MHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=60",
      title: "Beach day",
      likes: 198,
    },
  ] as PhotoItem[],
  videos: [
    {
      id: "v1",
      thumbnailUrl: "https://images.unsplash.com/photo-1496440737103-cd596325d314?ixid=MnwxMjA3fDB8MHxzZWFyY2h8MTB8fHZpZGVvfGVufDB8fDB8fA%3D%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=60",
      title: "City timelapse",
      likes: 432,
      duration: "0:45",
    },
    {
      id: "v2",
      thumbnailUrl: "https://images.unsplash.com/photo-1570101945621-945409a6370f?ixid=MnwxMjA3fDB8MHxzZWFyY2h8MTJ8fHRyYXZlbHxlbnwwfHwwfHw%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=60",
      title: "Travel vlog",
      likes: 287,
      duration: "2:30",
    },
  ] as VideoItem[],
  music: [
    {
      id: "m1",
      albumArt: "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?ixid=MnwxMjA3fDB8MHxzZWFyY2h8Mnx8bXVzaWN8ZW58MHx8MHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=60",
      title: "Summer vibes",
      artist: "Your name",
      likes: 532,
      duration: "3:45",
    },
    {
      id: "m2",
      albumArt: "https://images.unsplash.com/photo-1514320291840-2e0a9bf2a9ae?ixid=MnwxMjA3fDB8MHxzZWFyY2h8NXx8bXVzaWN8ZW58MHx8MHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=60",
      title: "Night drive",
      artist: "Your name",
      likes: 378,
      duration: "4:12",
    },
  ] as MusicItem[],
};

export default function ProfilePage() {
  const { data: session } = useSession();
  const [activeTab, setActiveTab] = useState("all");

  if (!session) {
    return (
      <div className="flex min-h-[50vh] flex-col items-center justify-center">
        <h1 className="text-2xl font-bold">Please sign in to view your profile</h1>
        <Button asChild className="mt-4">
          <Link href="/sign-in">Sign In</Link>
        </Button>
      </div>
    );
  }

  return (
    <div className="container mx-auto py-6 space-y-8">
      {/* Profile header */}
      <div className="flex flex-col md:flex-row gap-6 items-start">
        <Avatar className="w-24 h-24 md:w-36 md:h-36">
          <AvatarImage src={session.user.image || ""} alt={session.user.name || "User"} />
          <AvatarFallback className="text-2xl">{getInitials(session.user.name)}</AvatarFallback>
        </Avatar>

        <div className="flex-1 space-y-4">
          <div className="flex flex-col md:flex-row md:items-center gap-4 md:gap-6">
            <h1 className="text-2xl md:text-3xl font-bold">{session.user.name}</h1>
            {session.user.isPremium && (
              <Badge variant="outline" className="premium-badge w-fit">Premium</Badge>
            )}
            <div className="flex-1" />
            <Button variant="outline" size="sm" asChild>
              <Link href="/settings">
                <Settings className="h-4 w-4 mr-2" />
                Edit Profile
              </Link>
            </Button>
          </div>

          <div className="flex gap-6">
            <div className="text-center">
              <div className="font-medium">{PROFILE_DATA.stats.posts}</div>
              <div className="text-xs text-muted-foreground">Posts</div>
            </div>
            <div className="text-center">
              <div className="font-medium">{PROFILE_DATA.stats.followers}</div>
              <div className="text-xs text-muted-foreground">Followers</div>
            </div>
            <div className="text-center">
              <div className="font-medium">{PROFILE_DATA.stats.following}</div>
              <div className="text-xs text-muted-foreground">Following</div>
            </div>
          </div>

          <div className="text-sm">{PROFILE_DATA.bio}</div>

          <div className="flex flex-col gap-1 text-sm">
            <div className="flex items-center text-muted-foreground">
              <MapPin className="h-4 w-4 mr-2" />
              {PROFILE_DATA.location}
            </div>
            <div className="flex items-center text-muted-foreground">
              <LinkIcon className="h-4 w-4 mr-2" />
              <a href={PROFILE_DATA.website} target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">
                {PROFILE_DATA.website}
              </a>
            </div>
            <div className="flex items-center text-muted-foreground">
              <CalendarDays className="h-4 w-4 mr-2" />
              Joined {PROFILE_DATA.joinedDate}
            </div>
          </div>
        </div>
      </div>

      <Separator />

      {/* Content tabs */}
      <Tabs defaultValue="all" className="w-full" onValueChange={setActiveTab}>
        <ScrollArea className="w-full whitespace-nowrap">
          <TabsList className="inline-flex w-full h-11 items-center justify-start rounded-md bg-muted p-1 text-muted-foreground mb-4">
            <TabsTrigger value="all" className="rounded-sm px-4 py-2.5">
              <Grid className="h-4 w-4 mr-2" />
              All
            </TabsTrigger>
            <TabsTrigger value="photos" className="rounded-sm px-4 py-2.5">
              <Image className="h-4 w-4 mr-2" />
              Photos
            </TabsTrigger>
            <TabsTrigger value="videos" className="rounded-sm px-4 py-2.5">
              <Video className="h-4 w-4 mr-2" />
              Videos
            </TabsTrigger>
            <TabsTrigger value="music" className="rounded-sm px-4 py-2.5">
              <Music className="h-4 w-4 mr-2" />
              Music
            </TabsTrigger>
          </TabsList>
        </ScrollArea>

        <TabsContent value="all" className="space-y-4">
          {USER_CONTENT.music.length > 0 && (
            <div>
              <h2 className="text-xl font-bold mb-3">Music</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {USER_CONTENT.music.map((item) => (
                  <MusicCard key={item.id} item={item} />
                ))}
              </div>
            </div>
          )}

          {USER_CONTENT.videos.length > 0 && (
            <div>
              <h2 className="text-xl font-bold mb-3 mt-6">Videos</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {USER_CONTENT.videos.map((item) => (
                  <VideoCard key={item.id} item={item} />
                ))}
              </div>
            </div>
          )}

          {USER_CONTENT.photos.length > 0 && (
            <div>
              <h2 className="text-xl font-bold mb-3 mt-6">Photos</h2>
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                {USER_CONTENT.photos.map((item) => (
                  <PhotoCard key={item.id} item={item} />
                ))}
              </div>
            </div>
          )}
        </TabsContent>

        <TabsContent value="photos" className="space-y-4">
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {USER_CONTENT.photos.map((item) => (
              <PhotoCard key={item.id} item={item} />
            ))}
          </div>
        </TabsContent>

        <TabsContent value="videos" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {USER_CONTENT.videos.map((item) => (
              <VideoCard key={item.id} item={item} />
            ))}
          </div>
        </TabsContent>

        <TabsContent value="music" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {USER_CONTENT.music.map((item) => (
              <MusicCard key={item.id} item={item} />
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}

// Content card components
function PhotoCard({ item }: { item: PhotoItem }) {
  return (
    <Card className="media-card overflow-hidden h-full">
      <CardContent className="p-0 h-full">
        <div className="relative aspect-square w-full h-full">
          <img
            src={item.thumbnailUrl}
            alt={item.title}
            className="object-cover w-full h-full"
          />
          <div className="absolute inset-0 bg-black bg-opacity-20 opacity-0 hover:opacity-100 transition-opacity flex items-center justify-center">
            <div className="text-white text-center p-2">
              <div className="font-medium">{item.likes} likes</div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

function VideoCard({ item }: { item: VideoItem }) {
  return (
    <Card className="media-card overflow-hidden">
      <CardContent className="p-0">
        <div className="relative aspect-video w-full">
          <img
            src={item.thumbnailUrl}
            alt={item.title}
            className="object-cover w-full h-full"
          />
          <div className="absolute bottom-2 right-2 bg-black bg-opacity-70 text-white text-xs px-2 py-1 rounded">
            {item.duration}
          </div>
          <div className="absolute inset-0 bg-black bg-opacity-20 opacity-0 hover:opacity-100 transition-opacity flex items-center justify-center">
            <div className="text-white text-center p-2">
              <div className="font-medium">{item.title}</div>
              <div className="text-sm">{item.likes} likes</div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

function MusicCard({ item }: { item: MusicItem }) {
  return (
    <Card className="media-card overflow-hidden">
      <CardContent className="p-0">
        <div className="relative aspect-square w-full">
          <img
            src={item.albumArt}
            alt={item.title}
            className="object-cover w-full h-full"
          />
          <div className="absolute inset-0 bg-black bg-opacity-30 opacity-0 hover:opacity-100 transition-opacity flex items-center justify-center">
            <div className="text-white text-center p-2 space-y-1">
              <div className="font-medium">{item.title}</div>
              <div className="text-sm">{item.artist}</div>
              <div className="text-xs">{item.duration} • {item.likes} likes</div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
