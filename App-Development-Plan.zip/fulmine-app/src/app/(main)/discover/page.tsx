"use client";

import { useState, useEffect } from "react";
import { useSession } from "next-auth/react";
import {
  Search,
  Headphones,
  Film,
  Image,
  Mic,
  Clock,
  TrendingUp,
  Users,
  Music,
  Heart
} from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { AspectRatio } from "@/components/ui/aspect-ratio";
import { formatNumber, getInitials } from "@/lib/utils";
import Link from "next/link";

// Mock trending tags and topics
const TRENDING_TAGS = [
  "#musicproducer",
  "#newmusic",
  "#remix",
  "#photography",
  "#travelvideos",
  "#tiktokdance",
  "#trending",
  "#fyp",
  "#viral",
  "#creative",
];

// Mock popular categories
const POPULAR_CATEGORIES = [
  { id: "cat1", title: "Indie Music", icon: <Music className="h-5 w-5" />, count: "23.4K posts" },
  { id: "cat2", title: "Travel", icon: <Film className="h-5 w-5" />, count: "18.2K posts" },
  { id: "cat3", title: "Photography", icon: <Image className="h-5 w-5" />, count: "15.9K posts" },
  { id: "cat4", title: "EDM", icon: <Headphones className="h-5 w-5" />, count: "12.7K posts" },
  { id: "cat5", title: "Podcasts", icon: <Mic className="h-5 w-5" />, count: "9.5K posts" },
];

// Mock suggested creators to follow
const SUGGESTED_CREATORS = [
  {
    id: "u1",
    name: "Sarah Parker",
    avatar: "https://randomuser.me/api/portraits/women/12.jpg",
    isPremium: true,
    followers: 24500,
    description: "Music producer | DJ | Sound designer",
  },
  {
    id: "u2",
    name: "Alex Johnson",
    avatar: "https://randomuser.me/api/portraits/men/32.jpg",
    isPremium: false,
    followers: 18300,
    description: "Travel vlogger | Photographer | Adventure seeker",
  },
  {
    id: "u3",
    name: "Chris Wilson",
    avatar: "https://randomuser.me/api/portraits/men/51.jpg",
    isPremium: true,
    followers: 42800,
    description: "Electronic music artist | Spotify playlister",
  },
  {
    id: "u4",
    name: "Emma Lee",
    avatar: "https://randomuser.me/api/portraits/women/44.jpg",
    isPremium: true,
    followers: 31200,
    description: "Wellness podcaster | Meditation guide | Content creator",
  },
];

// Mock recommended content
const RECOMMENDED_CONTENT = [
  {
    id: "r1",
    type: "video",
    title: "Top travel destinations 2023",
    thumbnailUrl: "https://images.unsplash.com/photo-1469854523086-cc02fe5d8800?ixid=MnwxMjA3fDB8MHxzZWFyY2h8MTB8fHRyYXZlbHxlbnwwfHwwfHw%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=60",
    user: {
      id: "u2",
      name: "Alex Johnson",
      avatar: "https://randomuser.me/api/portraits/men/32.jpg",
      isPremium: false,
    },
    views: 45600,
    likes: 8900,
  },
  {
    id: "r2",
    type: "music",
    title: "Summer Nights - New EP",
    albumArt: "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?ixid=MnwxMjA3fDB8MHxzZWFyY2h8Mnx8bXVzaWN8ZW58MHx8MHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=60",
    user: {
      id: "u3",
      name: "Chris Wilson",
      avatar: "https://randomuser.me/api/portraits/men/51.jpg",
      isPremium: true,
    },
    plays: 128500,
    likes: 23400,
  },
  {
    id: "r3",
    type: "photo",
    title: "Urban photography collection",
    thumbnailUrl: "https://images.unsplash.com/photo-1477959858617-67f85cf4f1df?ixid=MnwxMjA3fDB8MHxzZWFyY2h8M3x8Y2l0eXxlbnwwfHwwfHw%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=60",
    user: {
      id: "u5",
      name: "Maya Thompson",
      avatar: "https://randomuser.me/api/portraits/women/22.jpg",
      isPremium: false,
    },
    views: 32400,
    likes: 5600,
  },
  {
    id: "r4",
    type: "audio",
    title: "Mindfulness Meditation Series",
    thumbnailUrl: "https://images.unsplash.com/photo-1506126613408-eca07ce68773?ixid=MnwxMjA3fDB8MHxzZWFyY2h8NHx8bWVkaXRhdGlvbnxlbnwwfHwwfHw%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=60",
    user: {
      id: "u4",
      name: "Emma Lee",
      avatar: "https://randomuser.me/api/portraits/women/44.jpg",
      isPremium: true,
    },
    plays: 89300,
    likes: 12800,
  },
];

export default function DiscoverPage() {
  const { data: session } = useSession();
  const [searchQuery, setSearchQuery] = useState("");
  const [activeTab, setActiveTab] = useState("foryou");

  return (
    <div className="container mx-auto py-6 space-y-8">
      <div className="flex flex-col gap-4">
        <h1 className="text-3xl font-bold">Discover</h1>
        <div className="relative max-w-4xl">
          <Search className="absolute left-3 top-1/2 h-5 w-5 -translate-y-1/2 transform text-muted-foreground" />
          <Input
            placeholder="Search for music, videos, people..."
            className="pl-10 h-12 text-lg"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
      </div>

      <Tabs defaultValue="foryou" onValueChange={setActiveTab}>
        <ScrollArea className="w-full whitespace-nowrap">
          <TabsList className="inline-flex w-full h-11 items-center justify-start rounded-md bg-muted p-1 text-muted-foreground mb-6">
            <TabsTrigger value="foryou" className="rounded-sm px-4 py-2.5">
              For You
            </TabsTrigger>
            <TabsTrigger value="trending" className="rounded-sm px-4 py-2.5">
              <TrendingUp className="h-4 w-4 mr-2" />
              Trending
            </TabsTrigger>
            <TabsTrigger value="creators" className="rounded-sm px-4 py-2.5">
              <Users className="h-4 w-4 mr-2" />
              Creators
            </TabsTrigger>
            <TabsTrigger value="recent" className="rounded-sm px-4 py-2.5">
              <Clock className="h-4 w-4 mr-2" />
              Recent
            </TabsTrigger>
          </TabsList>
        </ScrollArea>

        <TabsContent value="foryou" className="space-y-8">
          {/* Recommended Content Section */}
          <section>
            <h2 className="text-2xl font-bold mb-4">Recommended for you</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {RECOMMENDED_CONTENT.map((item) => (
                <Card key={item.id} className="media-card overflow-hidden">
                  <CardContent className="p-0">
                    <div className="relative">
                      <AspectRatio ratio={item.type === "music" ? 1 : 16/9}>
                        <img
                          src={item.type === "music" ? item.albumArt : item.thumbnailUrl}
                          alt={item.title}
                          className="object-cover w-full h-full"
                        />
                      </AspectRatio>
                      <div className="absolute top-2 right-2">
                        <Badge variant="secondary" className="text-xs font-medium">
                          {item.type.charAt(0).toUpperCase() + item.type.slice(1)}
                        </Badge>
                      </div>
                    </div>
                    <div className="p-4">
                      <h3 className="font-semibold text-lg truncate">{item.title}</h3>
                      <div className="flex items-center gap-2 mt-2">
                        <Avatar className="h-6 w-6">
                          <AvatarImage src={item.user.avatar} alt={item.user.name} />
                          <AvatarFallback>{getInitials(item.user.name)}</AvatarFallback>
                        </Avatar>
                        <span className="text-sm text-muted-foreground">
                          {item.user.name}
                          {item.user.isPremium && (
                            <span className="ml-1 premium-badge text-[10px]">Premium</span>
                          )}
                        </span>
                      </div>
                      <div className="flex items-center gap-4 mt-3 text-sm text-muted-foreground">
                        <div className="flex items-center gap-1">
                          {item.type === "music" || item.type === "audio" ? (
                            <Headphones className="h-4 w-4" />
                          ) : (
                            <EyeIcon className="h-4 w-4" />
                          )}
                          <span>
                            {formatNumber(item.type === "music" || item.type === "audio" ? item.plays : item.views)}
                          </span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Heart className="h-4 w-4" />
                          <span>{formatNumber(item.likes)}</span>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </section>

          {/* Suggested Creators Section */}
          <section>
            <h2 className="text-2xl font-bold mb-4">Creators to follow</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {SUGGESTED_CREATORS.map((creator) => (
                <Card key={creator.id} className="overflow-hidden">
                  <CardContent className="p-4">
                    <div className="flex flex-col items-center text-center">
                      <Avatar className="h-20 w-20 mb-3">
                        <AvatarImage src={creator.avatar} alt={creator.name} />
                        <AvatarFallback>{getInitials(creator.name)}</AvatarFallback>
                      </Avatar>
                      <h3 className="font-semibold text-lg">
                        {creator.name}
                        {creator.isPremium && (
                          <span className="ml-1 premium-badge text-xs">Premium</span>
                        )}
                      </h3>
                      <p className="text-sm text-muted-foreground mt-1">
                        {formatNumber(creator.followers)} followers
                      </p>
                      <p className="text-sm text-muted-foreground mt-2 mb-4 line-clamp-2">
                        {creator.description}
                      </p>
                      <Button variant="outline" className="w-full">
                        Follow
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </section>

          {/* Popular Categories Section */}
          <section>
            <h2 className="text-2xl font-bold mb-4">Popular Categories</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
              {POPULAR_CATEGORIES.map((category) => (
                <Card key={category.id} className="overflow-hidden">
                  <CardContent className="p-4">
                    <div className="flex items-center gap-3">
                      <div className="p-2 bg-primary/10 rounded-md text-primary">
                        {category.icon}
                      </div>
                      <div>
                        <h3 className="font-semibold">{category.title}</h3>
                        <p className="text-xs text-muted-foreground">{category.count}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </section>

          {/* Trending Tags Section */}
          <section>
            <h2 className="text-2xl font-bold mb-4">Trending Tags</h2>
            <div className="flex flex-wrap gap-2">
              {TRENDING_TAGS.map((tag) => (
                <Button key={tag} variant="outline" className="rounded-full">
                  {tag}
                </Button>
              ))}
            </div>
          </section>
        </TabsContent>

        <TabsContent value="trending" className="space-y-8">
          <div className="flex items-center justify-center min-h-[300px]">
            <p className="text-muted-foreground">Trending content would be displayed here</p>
          </div>
        </TabsContent>

        <TabsContent value="creators" className="space-y-8">
          <div className="flex items-center justify-center min-h-[300px]">
            <p className="text-muted-foreground">Creator suggestions would be displayed here</p>
          </div>
        </TabsContent>

        <TabsContent value="recent" className="space-y-8">
          <div className="flex items-center justify-center min-h-[300px]">
            <p className="text-muted-foreground">Recently viewed content would be displayed here</p>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}

interface IconProps extends React.SVGProps<SVGSVGElement> {}

function EyeIcon(props: IconProps) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      {...props}
    >
      <path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z" />
      <circle cx="12" cy="12" r="3" />
    </svg>
  );
}
