"use client";

import { useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Card,
  CardContent,
  CardFooter,
  CardHeader,
  CardTitle
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Separator } from "@/components/ui/separator";
import { Heart, MessageCircle, Share, Play, Music } from "lucide-react";
import { AspectRatio } from "@/components/ui/aspect-ratio";
import { formatTimeAgo, getInitials, formatNumber } from "@/lib/utils";
import Image from "next/image";
import Link from "next/link";

// Define content types
type ContentType = "video" | "photo" | "music" | "audio";

interface ContentUser {
  id: string;
  name: string;
  avatar: string;
  isPremium: boolean;
}

interface BaseContent {
  id: string;
  type: ContentType;
  title: string;
  caption: string;
  contentUrl: string;
  user: ContentUser;
  likes: number;
  comments: number;
  shares: number;
  createdAt: Date;
}

interface VideoContent extends BaseContent {
  type: "video";
  thumbnailUrl: string;
}

interface PhotoContent extends BaseContent {
  type: "photo";
  thumbnailUrl: string;
}

interface MusicContent extends BaseContent {
  type: "music";
  albumArt: string;
  duration: number;
}

interface AudioContent extends BaseContent {
  type: "audio";
  thumbnailUrl: string;
  duration: number;
}

type Content = VideoContent | PhotoContent | MusicContent | AudioContent;

// Mock data
const RECENT_CONTENT: Content[] = [
  {
    id: "p1",
    type: "video",
    title: "Summer trip highlights",
    caption: "Highlights from our summer vacation in Thailand! #travel #summer",
    thumbnailUrl: "https://images.unsplash.com/photo-1552733407-5d5c46c3bb3b?ixid=MnwxMjA3fDB8MHxzZWFyY2h8MTB8fHRyYXZlbHxlbnwwfHwwfHw%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=60",
    contentUrl: "https://example.com/video1.mp4",
    user: {
      id: "u1",
      name: "Sarah Parker",
      avatar: "https://randomuser.me/api/portraits/women/12.jpg",
      isPremium: true,
    },
    likes: 842,
    comments: 63,
    shares: 32,
    createdAt: new Date(Date.now() - 3600000), // 1 hour ago
  },
  {
    id: "p2",
    type: "photo",
    title: "City lights at dusk",
    caption: "The city looks magical during the blue hour ✨ #photography #cityscape",
    thumbnailUrl: "https://images.unsplash.com/photo-1519501025264-65ba15a82390?ixid=MnwxMjA3fDB8MHxzZWFyY2h8N3x8Y2l0eXxlbnwwfHwwfHw%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=60",
    contentUrl: "https://images.unsplash.com/photo-1519501025264-65ba15a82390?ixid=MnwxMjA3fDB8MHxzZWFyY2h8N3x8Y2l0eXxlbnwwfHwwfHw%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=60",
    user: {
      id: "u2",
      name: "Alex Johnson",
      avatar: "https://randomuser.me/api/portraits/men/32.jpg",
      isPremium: false,
    },
    likes: 1245,
    comments: 87,
    shares: 56,
    createdAt: new Date(Date.now() - 86400000), // 1 day ago
  },
  {
    id: "p3",
    type: "music",
    title: "Midnight Blues",
    caption: "My new single is out now! Let me know what you think 🎵 #music #newrelease",
    albumArt: "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?ixid=MnwxMjA3fDB8MHxzZWFyY2h8Mnx8bXVzaWN8ZW58MHx8MHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=60",
    contentUrl: "https://example.com/song1.mp3",
    duration: 187, // seconds
    user: {
      id: "u3",
      name: "Chris Wilson",
      avatar: "https://randomuser.me/api/portraits/men/51.jpg",
      isPremium: true,
    },
    likes: 532,
    comments: 48,
    shares: 112,
    createdAt: new Date(Date.now() - 172800000), // 2 days ago
  },
  {
    id: "p4",
    type: "audio",
    title: "Mindfulness Meditation",
    caption: "A guided meditation to help you relax and focus 🧘‍♀️ #wellness #meditation",
    thumbnailUrl: "https://images.unsplash.com/photo-1506126613408-eca07ce68773?ixid=MnwxMjA3fDB8MHxzZWFyY2h8NHx8bWVkaXRhdGlvbnxlbnwwfHwwfHw%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=60",
    contentUrl: "https://example.com/audio1.mp3",
    duration: 612, // seconds
    user: {
      id: "u4",
      name: "Emma Lee",
      avatar: "https://randomuser.me/api/portraits/women/44.jpg",
      isPremium: true,
    },
    likes: 329,
    comments: 21,
    shares: 45,
    createdAt: new Date(Date.now() - 345600000), // 4 days ago
  },
];

const TRENDING_CONTENT: Content[] = [
  {
    id: "p5",
    type: "video",
    title: "Dance challenge",
    caption: "Trying out the viral dance challenge! How did I do? 💃 #dancechallenge #viral",
    thumbnailUrl: "https://images.unsplash.com/photo-1537365587684-f490dff69960?ixid=MnwxMjA3fDB8MHxzZWFyY2h8MTV8fGRhbmNlfGVufDB8fDB8fA%3D%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=60",
    contentUrl: "https://example.com/video2.mp4",
    user: {
      id: "u5",
      name: "Ryan Cooper",
      avatar: "https://randomuser.me/api/portraits/men/62.jpg",
      isPremium: false,
    },
    likes: 15342,
    comments: 1287,
    shares: 3456,
    createdAt: new Date(Date.now() - 259200000), // 3 days ago
  },
  {
    id: "p6",
    type: "music",
    title: "Summer Vibes",
    caption: "The perfect track for your summer playlist 🏖️ #summerhits #feelgood",
    albumArt: "https://images.unsplash.com/photo-1501386761578-eac5c94b800a?ixid=MnwxMjA3fDB8MHxzZWFyY2h8MTB8fHN1bW1lcnxlbnwwfHwwfHw%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=60",
    contentUrl: "https://example.com/song2.mp3",
    duration: 213, // seconds
    user: {
      id: "u6",
      name: "Mia Rodriguez",
      avatar: "https://randomuser.me/api/portraits/women/63.jpg",
      isPremium: true,
    },
    likes: 12532,
    comments: 845,
    shares: 2311,
    createdAt: new Date(Date.now() - 432000000), // 5 days ago
  },
];

export default function HomePage() {
  const [activeTab, setActiveTab] = useState<"all" | ContentType>("all");

  // Filter content based on active tab
  const filterContent = (content: Content[]) => {
    if (activeTab === "all") return content;
    return content.filter(item => item.type === activeTab);
  };

  return (
    <div className="space-y-6">
      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <h1 className="text-3xl font-bold">Feed</h1>
        </div>

        <Tabs defaultValue="all" onValueChange={(value) => setActiveTab(value as "all" | ContentType)}>
          <ScrollArea className="w-full whitespace-nowrap">
            <TabsList className="inline-flex w-full h-11 items-center justify-start rounded-md bg-muted p-1 text-muted-foreground mb-4">
              <TabsTrigger value="all" className="rounded-sm px-4 py-2.5">
                All
              </TabsTrigger>
              <TabsTrigger value="video" className="rounded-sm px-4 py-2.5">
                Videos
              </TabsTrigger>
              <TabsTrigger value="photo" className="rounded-sm px-4 py-2.5">
                Photos
              </TabsTrigger>
              <TabsTrigger value="music" className="rounded-sm px-4 py-2.5">
                Music
              </TabsTrigger>
              <TabsTrigger value="audio" className="rounded-sm px-4 py-2.5">
                Audio
              </TabsTrigger>
            </TabsList>
          </ScrollArea>

          <TabsContent value={activeTab} className="space-y-6">
            <div>
              <h2 className="text-xl font-bold mb-4">Recent</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filterContent(RECENT_CONTENT).map((item) => (
                  <ContentCard key={item.id} content={item} />
                ))}
              </div>
            </div>

            <Separator />

            <div>
              <h2 className="text-xl font-bold mb-4">Trending</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filterContent(TRENDING_CONTENT).map((item) => (
                  <ContentCard key={item.id} content={item} />
                ))}
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </section>
    </div>
  );
}

function ContentCard({ content }: { content: Content }) {
  return (
    <Card className="media-card overflow-hidden">
      <CardHeader className="p-4">
        <div className="flex items-center space-x-3">
          <Avatar>
            <AvatarImage src={content.user.avatar} alt={content.user.name} />
            <AvatarFallback>{getInitials(content.user.name)}</AvatarFallback>
          </Avatar>
          <div>
            <Link href={`/profile/${content.user.id}`} className="font-semibold">
              {content.user.name}
              {content.user.isPremium && (
                <span className="ml-2 premium-badge">Premium</span>
              )}
            </Link>
            <p className="text-xs text-muted-foreground">
              {formatTimeAgo(content.createdAt)}
            </p>
          </div>
        </div>
      </CardHeader>
      <CardContent className="p-0">
        {content.type === "video" && (
          <div className="relative">
            <AspectRatio ratio={16/9}>
              <Image
                src={content.thumbnailUrl}
                alt={content.title}
                fill
                className="object-cover rounded-none"
              />
            </AspectRatio>
            <div className="absolute inset-0 flex items-center justify-center">
              <Button
                size="icon"
                variant="secondary"
                className="h-12 w-12 rounded-full opacity-90 hover:opacity-100"
              >
                <Play className="h-6 w-6" />
              </Button>
            </div>
          </div>
        )}
        {content.type === "photo" && (
          <AspectRatio ratio={4/3}>
            <Image
              src={content.thumbnailUrl}
              alt={content.title}
              fill
              className="object-cover rounded-none"
            />
          </AspectRatio>
        )}
        {content.type === "music" && (
          <div className="relative">
            <AspectRatio ratio={1}>
              <Image
                src={content.albumArt}
                alt={content.title}
                fill
                className="object-cover rounded-none"
              />
            </AspectRatio>
            <div className="absolute inset-0 flex items-center justify-center">
              <Button
                size="icon"
                variant="secondary"
                className="h-12 w-12 rounded-full opacity-90 hover:opacity-100"
              >
                <Music className="h-6 w-6" />
              </Button>
            </div>
          </div>
        )}
        {content.type === "audio" && (
          <AspectRatio ratio={16/9}>
            <Image
              src={content.thumbnailUrl}
              alt={content.title}
              fill
              className="object-cover rounded-none"
            />
          </AspectRatio>
        )}

        <div className="p-4">
          <div className="mb-2">
            <CardTitle className="text-lg">{content.title}</CardTitle>
          </div>
          <p className="text-sm text-muted-foreground">{content.caption}</p>
        </div>
      </CardContent>
      <CardFooter className="p-4 pt-0 flex items-center justify-between">
        <div className="flex space-x-4">
          <Button variant="ghost" size="sm" className="h-8 px-2">
            <Heart className="h-4 w-4 mr-1" />
            <span>{formatNumber(content.likes)}</span>
          </Button>
          <Button variant="ghost" size="sm" className="h-8 px-2">
            <MessageCircle className="h-4 w-4 mr-1" />
            <span>{formatNumber(content.comments)}</span>
          </Button>
        </div>
        <Button variant="ghost" size="sm" className="h-8 px-2">
          <Share className="h-4 w-4" />
        </Button>
      </CardFooter>
    </Card>
  );
}
