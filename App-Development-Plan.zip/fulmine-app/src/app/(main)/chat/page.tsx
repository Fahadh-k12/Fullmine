"use client";

import { useState } from "react";
import { useSession } from "next-auth/react";
import { Send, Search, Phone, Video, Info, Paperclip, Image as ImageIcon, Mic } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { formatTimeAgo, getInitials } from "@/lib/utils";
import Link from "next/link";

// Mock data
interface ChatMessage {
  id: string;
  content: string;
  senderId: string;
  timestamp: Date;
  isRead: boolean;
  contentType: "text" | "image" | "audio" | "video";
  mediaUrl?: string;
}

interface ChatContact {
  id: string;
  name: string;
  avatar: string | null;
  isPremium: boolean;
  lastMessage: ChatMessage | null;
  unreadCount: number;
  isOnline: boolean;
}

const CHAT_CONTACTS: ChatContact[] = [
  {
    id: "c1",
    name: "Sarah Parker",
    avatar: "https://randomuser.me/api/portraits/women/12.jpg",
    isPremium: true,
    isOnline: true,
    unreadCount: 2,
    lastMessage: {
      id: "m1",
      content: "Hey, did you check out my new song?",
      senderId: "c1",
      timestamp: new Date(Date.now() - 1000 * 60 * 5), // 5 minutes ago
      isRead: false,
      contentType: "text",
    },
  },
  {
    id: "c2",
    name: "Alex Johnson",
    avatar: "https://randomuser.me/api/portraits/men/32.jpg",
    isPremium: false,
    isOnline: false,
    unreadCount: 0,
    lastMessage: {
      id: "m2",
      content: "Let's meet tomorrow",
      senderId: "u1", // current user
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 2), // 2 hours ago
      isRead: true,
      contentType: "text",
    },
  },
  {
    id: "c3",
    name: "Emma Lee",
    avatar: "https://randomuser.me/api/portraits/women/44.jpg",
    isPremium: true,
    isOnline: true,
    unreadCount: 0,
    lastMessage: {
      id: "m3",
      content: "Check out this photo I took",
      senderId: "c3",
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24), // 1 day ago
      isRead: true,
      contentType: "text",
    },
  },
  {
    id: "c4",
    name: "Ryan Cooper",
    avatar: "https://randomuser.me/api/portraits/men/62.jpg",
    isPremium: false,
    isOnline: false,
    unreadCount: 0,
    lastMessage: {
      id: "m4",
      content: "Thanks for the feedback!",
      senderId: "c4",
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24 * 2), // 2 days ago
      isRead: true,
      contentType: "text",
    },
  },
];

// Mock conversation with the first contact
const CURRENT_CHAT_MESSAGES: ChatMessage[] = [
  {
    id: "cm1",
    content: "Hey there! How are you?",
    senderId: "c1", // contact
    timestamp: new Date(Date.now() - 1000 * 60 * 30), // 30 minutes ago
    isRead: true,
    contentType: "text",
  },
  {
    id: "cm2",
    content: "I'm good, thanks! Just working on some new music. How about you?",
    senderId: "u1", // current user
    timestamp: new Date(Date.now() - 1000 * 60 * 28), // 28 minutes ago
    isRead: true,
    contentType: "text",
  },
  {
    id: "cm3",
    content: "I'm doing well. Actually, I just released a new song!",
    senderId: "c1", // contact
    timestamp: new Date(Date.now() - 1000 * 60 * 25), // 25 minutes ago
    isRead: true,
    contentType: "text",
  },
  {
    id: "cm4",
    content: "That's awesome! I'd love to hear it.",
    senderId: "u1", // current user
    timestamp: new Date(Date.now() - 1000 * 60 * 20), // 20 minutes ago
    isRead: true,
    contentType: "text",
  },
  {
    id: "cm5",
    content: "Here's a preview",
    senderId: "c1", // contact
    timestamp: new Date(Date.now() - 1000 * 60 * 15), // 15 minutes ago
    isRead: true,
    contentType: "audio",
    mediaUrl: "https://example.com/audio.mp3",
  },
  {
    id: "cm6",
    content: "Sounds really good! Love the beats.",
    senderId: "u1", // current user
    timestamp: new Date(Date.now() - 1000 * 60 * 10), // 10 minutes ago
    isRead: true,
    contentType: "text",
  },
  {
    id: "cm7",
    content: "Thanks! I appreciate that. I'll be releasing the full song next week.",
    senderId: "c1", // contact
    timestamp: new Date(Date.now() - 1000 * 60 * 8), // 8 minutes ago
    isRead: true,
    contentType: "text",
  },
  {
    id: "cm8",
    content: "Hey, did you check out my new song?",
    senderId: "c1", // contact
    timestamp: new Date(Date.now() - 1000 * 60 * 5), // 5 minutes ago
    isRead: false,
    contentType: "text",
  },
];

export default function ChatPage() {
  const { data: session } = useSession();
  const [selectedContactId, setSelectedContactId] = useState<string | null>(CHAT_CONTACTS[0]?.id || null);
  const [messageInput, setMessageInput] = useState("");
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>(CURRENT_CHAT_MESSAGES);

  const selectedContact = CHAT_CONTACTS.find(contact => contact.id === selectedContactId) || null;

  const handleSendMessage = () => {
    if (!messageInput.trim() || !selectedContactId) return;

    const newMessage: ChatMessage = {
      id: `message-${Date.now()}`,
      content: messageInput,
      senderId: "u1", // current user
      timestamp: new Date(),
      isRead: false,
      contentType: "text",
    };

    setChatMessages([...chatMessages, newMessage]);
    setMessageInput("");
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  if (!session) {
    return (
      <div className="flex min-h-[50vh] flex-col items-center justify-center">
        <h1 className="text-2xl font-bold">Please sign in to use chat</h1>
        <Button asChild className="mt-4">
          <Link href="/sign-in">Sign In</Link>
        </Button>
      </div>
    );
  }

  return (
    <div className="container mx-auto py-6">
      <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-4 h-[80vh]">
        {/* Contact list */}
        <Card className="md:col-span-1 overflow-hidden">
          <div className="p-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 transform text-muted-foreground" />
              <Input
                placeholder="Search messages..."
                className="pl-10 w-full"
              />
            </div>
          </div>
          <Separator />
          <ScrollArea className="h-[calc(80vh-5rem)]">
            <div className="space-y-1 p-2">
              {CHAT_CONTACTS.map((contact) => (
                <button
                  key={contact.id}
                  className={`flex items-center gap-3 w-full p-3 rounded-lg text-left transition-colors ${
                    selectedContactId === contact.id
                      ? "bg-accent"
                      : "hover:bg-muted"
                  }`}
                  onClick={() => setSelectedContactId(contact.id)}
                >
                  <div className="relative">
                    <Avatar>
                      <AvatarImage src={contact.avatar || ""} alt={contact.name} />
                      <AvatarFallback>{getInitials(contact.name)}</AvatarFallback>
                    </Avatar>
                    {contact.isOnline && (
                      <span className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 border-2 border-background rounded-full" />
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex justify-between items-baseline">
                      <p className="font-medium truncate">
                        {contact.name}
                        {contact.isPremium && (
                          <span className="ml-2 premium-badge text-[10px]">Premium</span>
                        )}
                      </p>
                      {contact.lastMessage && (
                        <span className="text-xs text-muted-foreground">
                          {formatTimeAgo(contact.lastMessage.timestamp)}
                        </span>
                      )}
                    </div>
                    {contact.lastMessage && (
                      <p className="text-sm text-muted-foreground truncate">
                        {contact.lastMessage.senderId === "u1" ? "You: " : ""}
                        {contact.lastMessage.content}
                      </p>
                    )}
                  </div>
                  {contact.unreadCount > 0 && (
                    <span className="w-5 h-5 flex items-center justify-center bg-primary text-primary-foreground text-xs rounded-full">
                      {contact.unreadCount}
                    </span>
                  )}
                </button>
              ))}
            </div>
          </ScrollArea>
        </Card>

        {/* Chat area */}
        {selectedContact ? (
          <Card className="md:col-span-2 lg:col-span-3 flex flex-col">
            {/* Chat header */}
            <div className="flex items-center justify-between p-4 border-b">
              <div className="flex items-center gap-3">
                <Avatar>
                  <AvatarImage src={selectedContact.avatar || ""} alt={selectedContact.name} />
                  <AvatarFallback>{getInitials(selectedContact.name)}</AvatarFallback>
                </Avatar>
                <div>
                  <h2 className="font-medium">
                    {selectedContact.name}
                    {selectedContact.isPremium && (
                      <span className="ml-2 premium-badge text-xs">Premium</span>
                    )}
                  </h2>
                  <p className="text-xs text-muted-foreground">
                    {selectedContact.isOnline ? "Online" : "Offline"}
                  </p>
                </div>
              </div>
              <div className="flex gap-2">
                <Button variant="ghost" size="icon">
                  <Phone className="h-5 w-5" />
                </Button>
                <Button variant="ghost" size="icon">
                  <Video className="h-5 w-5" />
                </Button>
                <Button variant="ghost" size="icon">
                  <Info className="h-5 w-5" />
                </Button>
              </div>
            </div>

            {/* Chat messages */}
            <ScrollArea className="flex-1 p-4">
              <div className="space-y-4">
                {chatMessages.map((message) => (
                  <div
                    key={message.id}
                    className={`flex ${
                      message.senderId === "u1" ? "justify-end" : "justify-start"
                    }`}
                  >
                    <div
                      className={`chat-bubble ${
                        message.senderId === "u1"
                          ? "chat-bubble-sender"
                          : "chat-bubble-receiver"
                      }`}
                    >
                      {message.contentType === "text" ? (
                        <p>{message.content}</p>
                      ) : message.contentType === "audio" ? (
                        <div className="flex items-center gap-2 bg-muted/20 p-2 rounded-md">
                          <Mic className="h-4 w-4" />
                          <span className="text-sm">Audio message</span>
                          <span className="text-xs text-muted-foreground ml-auto">0:30</span>
                        </div>
                      ) : null}
                      <div className="text-xs text-right mt-1 opacity-70">
                        {formatTimeAgo(message.timestamp)}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </ScrollArea>

            {/* Message input */}
            <div className="p-4 border-t flex gap-2">
              <Button variant="ghost" size="icon">
                <Paperclip className="h-5 w-5" />
              </Button>
              <Button variant="ghost" size="icon">
                <ImageIcon className="h-5 w-5" />
              </Button>
              <Button variant="ghost" size="icon">
                <Mic className="h-5 w-5" />
              </Button>
              <Input
                placeholder="Type a message..."
                value={messageInput}
                onChange={(e) => setMessageInput(e.target.value)}
                onKeyDown={handleKeyPress}
                className="flex-1"
              />
              <Button
                onClick={handleSendMessage}
                disabled={!messageInput.trim()}
                size="icon"
              >
                <Send className="h-5 w-5" />
              </Button>
            </div>
          </Card>
        ) : (
          <Card className="md:col-span-2 lg:col-span-3 flex items-center justify-center">
            <div className="text-center p-6">
              <h2 className="text-xl font-bold mb-2">Select a conversation</h2>
              <p className="text-muted-foreground">
                Choose a contact from the list to start chatting
              </p>
            </div>
          </Card>
        )}
      </div>
    </div>
  );
}
