import { createUploadthing, type FileRouter } from "uploadthing/next";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";

const f = createUploadthing();

// Auth middleware
const auth = async () => {
  const session = await getServerSession(authOptions);
  const user = session?.user;

  if (!user) throw new Error("Unauthorized");

  return { userId: user.id, isPremium: user.isPremium };
};

// FileRouter for your app, can contain multiple FileRoutes
export const ourFileRouter = {
  // Define as many FileRoutes as you like, each with a unique routeSlug
  image: f({ image: { maxFileSize: "4MB", maxFileCount: 5 } })
    // Set permissions and file types for this FileRoute
    .middleware(async () => {
      const { userId } = await auth();
      return { userId };
    })
    .onUploadComplete(async ({ metadata, file }) => {
      // This code RUNS ON YOUR SERVER after upload
      console.log("Upload complete for userId:", metadata.userId);

      // Return necessary data to the client
      return { uploadedBy: metadata.userId, url: file.url };
    }),

  video: f({ video: { maxFileSize: "16MB", maxFileCount: 1 } })
    .middleware(async () => {
      const { userId } = await auth();
      return { userId };
    })
    .onUploadComplete(async ({ metadata, file }) => {
      return { uploadedBy: metadata.userId, url: file.url };
    }),

  // Premium users can upload music
  audio: f({ audio: { maxFileSize: "16MB", maxFileCount: 1 } })
    .middleware(async () => {
      const { userId, isPremium } = await auth();

      if (!isPremium) {
        throw new Error("Only premium users can upload music.");
      }

      return { userId, isPremium };
    })
    .onUploadComplete(async ({ metadata, file }) => {
      return { uploadedBy: metadata.userId, url: file.url };
    }),
} satisfies FileRouter;

export type OurFileRouter = typeof ourFileRouter;
