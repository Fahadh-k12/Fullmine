import Link from "next/link";
import { Toaster } from "@/components/ui/toaster";
import { APP_NAME } from "@/lib/constants";

export default function AuthLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <div className="min-h-screen flex flex-col">
      <header className="border-b border-border">
        <div className="container mx-auto py-4 px-4">
          <Link href="/" className="flex items-center gap-2">
            <span className="text-2xl font-bold gradient-text">{APP_NAME}</span>
          </Link>
        </div>
      </header>
      <main className="flex-1 flex items-center justify-center">
        {children}
      </main>
      <Toaster />
    </div>
  );
}
