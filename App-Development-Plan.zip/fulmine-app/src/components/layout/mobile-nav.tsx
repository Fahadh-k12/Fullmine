"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  Home,
  Compass,
  MessageCircle,
  User,
  Upload,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { NAVIGATION_ITEMS } from "@/lib/constants";

// Map icons to navigation items
const iconMap: Record<string, React.ReactNode> = {
  home: <Home className="h-6 w-6" />,
  compass: <Compass className="h-6 w-6" />,
  "message-circle": <MessageCircle className="h-6 w-6" />,
  user: <User className="h-6 w-6" />,
  upload: <Upload className="h-6 w-6" />,
};

export default function MobileNav() {
  const pathname = usePathname();

  return (
    <div className="md:hidden fixed bottom-0 left-0 right-0 z-50 bg-background border-t border-border">
      <div className="flex items-center justify-around py-2">
        {NAVIGATION_ITEMS.map((item) => (
          <Link
            key={item.href}
            href={item.href}
            className={cn(
              "flex flex-col items-center p-2 transition-colors rounded-md",
              pathname === item.href
                ? "text-primary"
                : "text-muted-foreground hover:text-foreground"
            )}
          >
            <div className="mb-1">
              {iconMap[item.icon]}
            </div>
            <span className="text-xs font-medium">{item.title}</span>
          </Link>
        ))}
      </div>
    </div>
  );
}
