export const APP_NAME = "Fulmine";

export const NAVIGATION_ITEMS = [
  {
    title: "Home",
    href: "/",
    icon: "home",
  },
  {
    title: "Discover",
    href: "/discover",
    icon: "compass",
  },
  {
    title: "Chat",
    href: "/chat",
    icon: "message-circle",
  },
  {
    title: "Profile",
    href: "/profile",
    icon: "user",
  },
  {
    title: "Upload",
    href: "/upload",
    icon: "upload",
  },
];

export const CONTENT_CATEGORIES = [
  { title: "Music", value: "music" },
  { title: "Videos", value: "video" },
  { title: "Photos", value: "photo" },
  { title: "Audio", value: "audio" },
];

export const MUSIC_GENRES = [
  { title: "Pop", value: "pop" },
  { title: "Hip Hop", value: "hiphop" },
  { title: "Rock", value: "rock" },
  { title: "R&B", value: "rnb" },
  { title: "EDM", value: "edm" },
  { title: "Country", value: "country" },
  { title: "Jazz", value: "jazz" },
  { title: "Classical", value: "classical" },
  { title: "Alternative", value: "alternative" },
  { title: "Reggae", value: "reggae" },
];

export const VIDEO_CATEGORIES = [
  { title: "Vlogs", value: "vlogs" },
  { title: "Tutorials", value: "tutorials" },
  { title: "Entertainment", value: "entertainment" },
  { title: "Comedy", value: "comedy" },
  { title: "Music Videos", value: "music-videos" },
  { title: "Gaming", value: "gaming" },
  { title: "Travel", value: "travel" },
  { title: "Sports", value: "sports" },
  { title: "News & Politics", value: "news-politics" },
];

export const PHOTO_CATEGORIES = [
  { title: "Portrait", value: "portrait" },
  { title: "Landscape", value: "landscape" },
  { title: "Street", value: "street" },
  { title: "Fashion", value: "fashion" },
  { title: "Wildlife", value: "wildlife" },
  { title: "Architecture", value: "architecture" },
  { title: "Food", value: "food" },
  { title: "Travel", value: "travel" },
  { title: "Sports", value: "sports" },
  { title: "Abstract", value: "abstract" },
];
